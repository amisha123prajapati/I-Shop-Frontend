import React from 'react';
// Import components
import Cart from '../Components/cart/Cart';

const CartPage = () => {
    return (
        <div>
            <Cart />
        </div>
    );
};

export default CartPage;
