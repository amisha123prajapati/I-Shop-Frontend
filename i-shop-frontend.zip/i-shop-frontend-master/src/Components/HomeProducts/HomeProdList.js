export const title = {name: "BEST SELLER"}

export const prodNavItems = [
    {item: "Men", path: "/mens"},
    {item: "Women", path: "/womens"},
    {item: "Gadgets", path: "/gadgets"},
    {item: "Jewellery", path: "/jewelleries"}
]

