export const FilterNavList = [
    {name: "Items"},
    {name: "Sort By", select: "New Trend"},
    {name: "Show", select: "All Products"}
];
