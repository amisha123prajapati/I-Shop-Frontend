export const PageCallList = {
    Shop: "SHOP",
    Men: "MEN",
    Women: "WOMEN",
    Accessories: "ACCESSORIES",
    Jewellery: "JEWELLERY"
}; 
