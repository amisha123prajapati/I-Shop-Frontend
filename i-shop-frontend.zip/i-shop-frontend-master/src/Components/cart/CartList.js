export const CartListLeft = {name: "PRODUCT"}

export const CartListRight = [
    {name: "TOTAL PRICE"},
    {name: "QTY"},
    {name: "UNIT PRICE"}
];
