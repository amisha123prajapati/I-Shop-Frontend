export const CategoryList = [
    {
        name: "CATEGORIES",
        category: [
            {name: "Men", to: "/mens"},
            {name: "Women", to: "/womens"},
            {name: "Gadgets", to: "/gadgets"},
            {name: "Jewellery", to: "/jewelleries"},
        ]
    }
];
