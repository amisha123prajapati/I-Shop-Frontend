import React from 'react';

const HotLabel = () => {
    return (
        <div className="hot">
            <p className="hot-para">HOT</p>
        </div>
    );
};

export default HotLabel;
