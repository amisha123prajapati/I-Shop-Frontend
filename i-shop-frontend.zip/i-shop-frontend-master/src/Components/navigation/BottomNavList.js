export const brand = {
    name: "iSHOP"
}

export const NavItems = [
    {name: "HOME", to: "/"},
    {name: "STORE", to: "#"},
    {name: "MEN", to: "/mens"},
    {name: "WOMEN", to: "/womens"},
    {name: "GADGETS", to: "/gadgets"},
    {name: "JEWELLERY", to: "/jewelleries"}
]

