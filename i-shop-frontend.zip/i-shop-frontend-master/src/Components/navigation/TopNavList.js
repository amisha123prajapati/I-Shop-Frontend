export const TopLeft = [
    {for: "language", name: "language", label: "EN", option: "EN"},
    {for: "dollar", name: "dollar", label: "$", option: "$"}
];

export const TopRight = {
    profile: "My profile",
    bag: "Items"
};
