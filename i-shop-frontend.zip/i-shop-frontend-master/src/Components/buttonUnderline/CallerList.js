export const HomeProductSection = {
    text: "LOAD MORE",
    path: "/shop",
    color: "#33A0FF",
}

export const MidSection = {
    text: "SHOP NOW",
    path: "/shop",
    color: "#FFF",
}
