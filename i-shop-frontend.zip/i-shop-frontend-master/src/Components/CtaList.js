export const CtaList = {
    buy: "BUY NOW",
    butTo: "/cart",
    checkout: "CHECK OUT",
    checkoutTo: "/checkout"
}
