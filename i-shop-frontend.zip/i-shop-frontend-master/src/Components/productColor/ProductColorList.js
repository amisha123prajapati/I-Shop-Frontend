export const ProductColorList = [{
    head: "COLOR",
    colors: [
        {color: "#006CFF"},
        {color: "#FC3E39"},
        {color: "#171717"},
        {color: "#FFF600"}
    ]
}];
