export const Loading = {
    message: "SHHHH LOADING...",
    productLoading: "Style is the way to say who you are without having to speak..."
}

