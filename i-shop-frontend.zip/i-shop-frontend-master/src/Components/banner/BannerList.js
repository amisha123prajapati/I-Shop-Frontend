// Home page
export const headerTopImage = {
    imageUrl: "https://i.ibb.co/TkF9Wmy/mockup.png"
};

export const MobheaderTopImage = {
    imageUrl: "https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80"
};

export const homeText = {
    heading: "i Phone 13",
    para: "Performance and design. Taken right to the edge.",
    btnName: "SHOP NOW"
}   

// Shop Page
export const ShopBannerImage = {
    imageUrl: "https://i.ibb.co/0CJRGbK/pexels-photo-919436-removebg-preview.png"
};

export const ShopBannerText = {
    heading: "Treat yo’ self.",
    para: "You can always find something you want.",
    btnName: "SHOP NOW"
}
