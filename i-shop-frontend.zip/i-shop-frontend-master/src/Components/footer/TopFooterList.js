export const TopFooterList = [
    {
        title: "iSHOP",
        desc: "We believe in creating the kind of fashion, that makes you stand out as they are in line with the latest local and global trends of the industry."
    },
    {
        title: "Follow Us",
        desc: "Follow us for fresh product updates",
        icons: [
            {logo: "fab fa-facebook"},
            {logo: "fab fa-twitter"}
        ]
    },
    {
        title: "Contact Us",
        desc: "Email: contact@ishop.com"
    }
];
