export const BottomFooterList = [
    {
        title: "Information",
        links: [
            {name: "About Us"},
            {name: "Terms and Conditions"},
            {name: "Privacy Policy"}
        ]
    },
    {
        title: "Service",
        links: [
            {name: "service Info"},
            {name: "Instant Delivery"}
        ]
    },
    {
        title: "Customers",
        links: [
            {name: "Track Order"},
            {name: "Return Order"},
            {name: "Cancel Order"}
        ]
    },
    {
        title: "Useful Links",
        links: [
            {name: "Blog"},
            {name: "Return Policy"}
        ]
    }
];
