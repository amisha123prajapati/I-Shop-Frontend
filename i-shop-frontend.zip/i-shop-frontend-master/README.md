
# iSHOP An e-commerce full stack web app with payment gateway integration

## View Live:

https://aishop.netlify.app/

  
## Tech Stack

**Frontend:** React, Redux

**Backend:** Node, Express, MongoDB
